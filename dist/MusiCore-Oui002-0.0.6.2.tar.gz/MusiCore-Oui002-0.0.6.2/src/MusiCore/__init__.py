from MusiCore.Player import StreamPlayer
import MusiCore.Stream